import Foundation
import UIKit

class InfoViewController: UIViewController{
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var infoImageView: UIImageView!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    var annotation: CustomAnnotation!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        infoLabel.text = annotation.title!
        
        descriptionLabel.text = annotation.info!
    
    
    }
    
    
}
