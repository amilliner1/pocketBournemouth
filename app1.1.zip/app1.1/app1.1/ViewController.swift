import UIKit
import MapKit


class ViewController: UIViewController {
    @IBOutlet weak var labelOne: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var mapView: MKMapView!
 
let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    locationManager.requestAlwaysAuthorization()

    locationManager.startUpdatingLocation()
    
    mapView.userTrackingMode = .follow
    
    let coordinate = CLLocationCoordinate2D(latitude: 50.715634, longitude: -1.874866)
    let region = CLCircularRegion(center: coordinate, radius: 100, identifier: "Pier")
    locationManager.startMonitoring(for: region)
    
    
    let annotation = CustomAnnotation(coordinate: CLLocationCoordinate2D(50.741972, -1.897156))
    annotation.coordinate = CLLocationCoordinate2DMake(50.741972, -1.897156)
    mapView.addAnnotation(annotation)
    annotation.title = "Talbot Campus"
    
    let annotationTwo = MKPointAnnotation()
    annotationTwo.title = "Bournemouth Pier"
    annotationTwo.coordinate = CLLocationCoordinate2DMake(50.715634, -1.874866)
    mapView.addAnnotation(annotationTwo)
    
    let annotationThree = MKPointAnnotation()
    annotationThree.title = "Bournemouth Gardens"
    annotationThree.coordinate = CLLocationCoordinate2DMake(50.7174, -1.8763)
    mapView.addAnnotation(annotationThree)
    
    mapView.delegate = self
    mapView.showsUserLocation = true
    mapView.showAnnotations([annotation], animated: true)
    
    let region = MKCoordinateRegion( center: annotation.coordinate, latitudinalMeters: 5000, longitudinalMeters: 5000)
    mapView.setRegion(region, animated: true)
        
    }

    @IBAction func openButton(_ sender: Any) {
    }
    
}


extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
}
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
    imageView.image = UIImage(named: region.identifier)
    labelOne.text = region.identifier
}
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
    imageView.image = nil
    labelOne.text = nil

}

    var ViewController: MKMapViewDelegate{
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        labelOne.text = view.annotation!.title!
    
    
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {

    if annotation is MKUserLocation { return nil }
    
    let annotationView: MKMarkerAnnotationView?

    if let dequedView = mapView.dequeueReusableAnnotationView(withIdentifier: "identifier") as? MKMarkerAnnotationView {
        annotationView = dequedView
    } else{
        annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "identifier")
    }
}
}
}
