import UIKit
import Foundation

class InfoViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    
    }
}
