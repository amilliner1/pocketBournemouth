import UIKit
import MapKit


class ViewController: UIViewController {
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var labelTwo: UILabel!
    
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.requestAlwaysAuthorization()

        locationManager.startUpdatingLocation()
        locationManager.delegate = self
        mapView.userTrackingMode = .follow
        
        
        
        let talbotCoord = CLLocationCoordinate2DMake(50.741972, -1.897156)
        let annotation = CustomAnnotation(coordinate: talbotCoord, title: "Talbot", info: "Talbot campus is where the majority of Bournemouth University's facilities can be located, as well as the main facilities such as The Sir Michael Cobham library, the student center and SportBU. Talbot was established in 1992 and has an active alumni of 58,285.")
        mapView.addAnnotation(annotation)
        locationManager.startMonitoring(for: annotation.region)
        
        
        let pierCoord = CLLocationCoordinate2DMake(50.715634, -1.874866)
        let annotationTwo = CustomAnnotation(coordinate: pierCoord, title: "Bournemouth Pier", info: "Costing an approximate £2600, Bournemouth Pier opened in 1880. Located on the seafront next to the Ferris wheel at the back end of Bournemouth Gardens. The pier is a must-visit attraction, with a beautiful seaside view. The attractions consist of an indoor climbing wall & zipwire accompanied by cafes, gift shops and a restaurant.")
        mapView.addAnnotation(annotationTwo)
        locationManager.startMonitoring(for: annotationTwo.region)
    
        
        let gardenCoord = CLLocationCoordinate2DMake(50.718600, -1.875090)
        let annotationThree = CustomAnnotation(coordinate: gardenCoord, title: "Gardens", info: "Located between Bournemouth town center and the seafront, Bournemouth Gardens is approximately 3 kilometers long. The upper, central and lower gardens have all been Green Flag winners since 1999. The garden contains many year-round attractions such as a mini golf course, a play park with a zip line, refreshment kiosks, café and much more. Seasonal events take place throughout the year including the Christmas Tree Wonderland.")
        mapView.addAnnotation(annotationThree)
        locationManager.startMonitoring(for: annotationThree.region)

        
        let vitalityCoord = CLLocationCoordinate2DMake(50.733820, -1.838950)
        let annotationFour = CustomAnnotation(coordinate: vitalityCoord, title: "Vitality Stadium", info: "Home to the Premier league team AFC Bournemouth, Vitality stadium formally known as Dean Court opened in 1910, and can currently hold a capacity of 11,000 fans. Not only has the Vitality provided for AFC Bournemouth but has also been the venue for Elton John (2006) and England Ladies (2013).")
        mapView.addAnnotation(annotationFour)
        locationManager.startMonitoring(for: annotationFour.region)

        
        mapView.delegate = self
        mapView.showsUserLocation = true
        mapView.showAnnotations(mapView.annotations, animated: true)
            
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
      if segue.identifier == "InfoPass" {
        guard let annotation = sender as? CustomAnnotation else { return }
          let infoVC = segue.destination as! InfoViewController
          infoVC.annotation = annotation
      }
      
    }
   
    
    
    @IBAction func openButton(_ sender: Any) {
    }
    
    
}


extension ViewController: CLLocationManagerDelegate {
  
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {

      
        for annotation in mapView.annotations {
            if annotation.title == region.identifier {
                if let annotation = annotation as? CustomAnnotation {
                    print(annotation.title)
                  annotation.active = true
                }
            }
        }
        
        
    }
    
  
  
    
    
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {

        labelTwo.text = "You're not here yet, please enter region and try again"
      for annotation in mapView.annotations {
        if let annotation = annotation as? CustomAnnotation {
          annotation.active = false
        }
      }
        
    }

}



extension ViewController: MKMapViewDelegate {

    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        guard let annotation = view.annotation as? CustomAnnotation else {return}
        guard annotation.active else { return }
        performSegue(withIdentifier: "InfoPass", sender: annotation)
        mapView.deselectAnnotation(annotation, animated: true)
    }

}
