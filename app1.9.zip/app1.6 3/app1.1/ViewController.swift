import UIKit
import MapKit


class ViewController: UIViewController {
    @IBOutlet weak var labelOne: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var mapView: MKMapView!
 
let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.requestAlwaysAuthorization()

        locationManager.startUpdatingLocation()
        locationManager.delegate = self
        mapView.userTrackingMode = .follow
        
        
        
        let x = CLLocationCoordinate2DMake(50.715634, -1.874866)
        let annotationTwo = CustomAnnotation(coordinate: x, title: "Bournemouth Pier", info: "dshjakdhsajkdhsajkdhsajkdshajk")
        mapView.addAnnotation(annotationTwo)
        locationManager.startMonitoring(for: annotationTwo.region)
        imageView.image = UIImage.init(named: "Bournemouth Pier")
         
    
        let y = CLLocationCoordinate2DMake(50.741972, -1.897156)
        let annotation = CustomAnnotation(coordinate: y, title: "Talbot", info: "dshjakdhsajkdhsajkdhsajkdshajk")
        mapView.addAnnotation(annotation)
        locationManager.startMonitoring(for: annotation.region)
        imageView.image = UIImage.init(named: "Talbot")
        
        let z = CLLocationCoordinate2DMake(50.718600, -1.875090)
        let annotationThree = CustomAnnotation(coordinate: z, title: "Gardens", info: "dshjakdhsajkdhsajkdhsajkdshajk")
        mapView.addAnnotation(annotationThree)
        locationManager.startMonitoring(for: annotationThree.region)
        imageView.image = UIImage.init(named: "Gardens")
        
        let c = CLLocationCoordinate2DMake(50.733820, -1.838950)
        let annotationFour = CustomAnnotation(coordinate: c, title: "Vitality Stadium", info: "dshjakdhsajkdhsajkdhsajkdshajk")
        mapView.addAnnotation(annotationFour)
        locationManager.startMonitoring(for: annotationFour.region)
        imageView.image = UIImage.init(named: "Vitality Stadium")
        
        
        mapView.delegate = self
        mapView.showsUserLocation = true
        mapView.showAnnotations(mapView.annotations, animated: true)
            
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "InfoPass" {
            let infoVC = segue.destination as! InfoViewController
            infoVC.annotation = sender as? CustomAnnotation
            //Set the data you want to pass...
        }
    }
   
    
    
    @IBAction func openButton(_ sender: Any) {
    }
    
    
}


extension ViewController: CLLocationManagerDelegate {
  
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        
        
        for annotation in mapView.annotations {
            if annotation.title == region.identifier {
                if let annotation = annotation as? CustomAnnotation {
                    print(annotation.title)

                }
            }
        }
        
        
    }
    
    
    
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        imageView.image = nil
        labelOne.text = nil

    }

}



extension ViewController: MKMapViewDelegate {

    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        guard let annotation = view.annotation as? CustomAnnotation else {return}
        performSegue(withIdentifier: "InfoPass", sender: annotation)
        mapView.deselectAnnotation(annotation, animated: true)

        
    }

}

//    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
//
//        if annotation is MKUserLocation { return nil }
//
//            let annotationView: MKMarkerAnnotationView?
//
//            if let dequedView = mapView.dequeueReusableAnnotationView(withIdentifier: "identifier") as? MKMarkerAnnotationView {
//                annotationView = dequedView
//            } else{
//                annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "identifier")
//            }
//        }
//    }
