import UIKit
import MapKit


class ViewController: UIViewController {
    @IBOutlet weak var labelOne: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var mapView: MKMapView!
 
let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    locationManager.requestAlwaysAuthorization()

    locationManager.startUpdatingLocation()
    
    mapView.userTrackingMode = .follow
    
    let coordinate = CLLocationCoordinate2D(latitude: 50.715634, longitude: -1.874866)
    let region = CLCircularRegion(center: coordinate, radius: 100, identifier: "Pier")
    locationManager.startMonitoring(for: region)
    
    
    let annotation = MKPointAnnotation()
    annotation.coordinate = CLLocationCoordinate2DMake(50.741972, -1.897156)
    mapView.addAnnotation(annotation)
    annotation.title = "Talbot Campus"
    
    let annotationTwo = MKPointAnnotation()
    annotationTwo.title = "Bournemouth Pier"
    annotationTwo.coordinate = CLLocationCoordinate2DMake(50.715634, -1.874866)
    mapView.addAnnotation(annotationTwo)
    
    let annotationThree = MKPointAnnotation()
    annotationThree.title = "Bournemouth Gardens"
    annotationThree.coordinate = CLLocationCoordinate2DMake(50.7174, -1.8763)
    mapView.addAnnotation(annotationThree)
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
      print("Entered: \(region.identifier)")
    }
   
        
    }

    @IBAction func openButton(_ sender: Any) {
        
        
        
        
    }
    
}



    
 



